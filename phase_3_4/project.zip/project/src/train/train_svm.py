#!/usr/bin/env python3
"""
train_svm.py
Train SVM classifier on extracted autoencoder features using GPU (cuML) or CPU (sklearn)

Dataset Organization:
  - Training: 50,000 samples with extracted features (8192-dim) + labels
  - Evaluation: 10,000 test samples with extracted features + labels
  
The features were extracted by the autoencoder's encoder from CIFAR-10 images.
SVM learns to classify these latent representations into 10 classes.

Usage:
    python train_svm.py --features cifar10_features --epochs 20
"""

import numpy as np
import struct
import time

def load_features(prefix):
    """Load features and labels from binary files."""
    
    def load_bin(filename, is_features=True):
        with open(filename, 'rb') as f:
            if is_features:
                num_samples = struct.unpack('i', f.read(4))[0]
                latent_dim = struct.unpack('i', f.read(4))[0]
                data = np.frombuffer(f.read(), dtype=np.float32)
                return data.reshape(num_samples, latent_dim)
            else:
                num_samples = struct.unpack('i', f.read(4))[0]
                data = np.frombuffer(f.read(), dtype=np.int32)
                return data
    
    print("Loading features...")
    X_train = load_bin(f"{prefix}_train_features.bin", is_features=True)
    y_train = load_bin(f"{prefix}_train_labels.bin", is_features=False)
    X_test = load_bin(f"{prefix}_test_features.bin", is_features=True)
    y_test = load_bin(f"{prefix}_test_labels.bin", is_features=False)
    
    print(f"  Train: {X_train.shape[0]} samples, {X_train.shape[1]} features")
    print(f"  Test:  {X_test.shape[0]} samples, {X_test.shape[1]} features")
    
    return X_train, y_train, X_test, y_test


def normalize_features(X_train, X_test):
    """Normalize features to zero mean, unit variance."""
    mean = X_train.mean(axis=0)
    std = X_train.std(axis=0) + 1e-8
    X_train_norm = (X_train - mean) / std
    X_test_norm = (X_test - mean) / std
    return X_train_norm, X_test_norm


def train_svm_gpu(X_train, y_train, X_test, y_test, epochs=20, C=1.0):
    """Train SVM using cuML (GPU accelerated)."""
    try:
        import cupy as cp
        from cuml.svm import SVC
        from cuml.metrics import accuracy_score
        print("\nUsing cuML (GPU) for SVM training")
    except ImportError:
        print("cuML not available, falling back to CPU")
        return train_svm_cpu(X_train, y_train, X_test, y_test, epochs, C)
    
    # Convert to GPU arrays
    X_train_gpu = cp.asarray(X_train, dtype=cp.float32)
    y_train_gpu = cp.asarray(y_train, dtype=cp.int32)
    X_test_gpu = cp.asarray(X_test, dtype=cp.float32)
    y_test_gpu = cp.asarray(y_test, dtype=cp.int32)
    
    print(f"\nTraining SVM with C={C}")
    print("=" * 60)
    
    best_acc = 0.0
    best_model = None
    
    # cuML SVM doesn't have epochs like neural networks
    # We'll simulate epochs by training with increasing subsets and different C values
    C_values = np.logspace(-2, 2, epochs)  # C from 0.01 to 100
    
    for epoch in range(epochs):
        C_current = C_values[epoch]
        
        start_time = time.time()
        
        # Train SVM
        svm = SVC(C=C_current, kernel='rbf', gamma='scale', cache_size=2000)
        svm.fit(X_train_gpu, y_train_gpu)
        
        # Predict
        y_pred_train = svm.predict(X_train_gpu)
        y_pred_test = svm.predict(X_test_gpu)
        
        # Accuracy
        train_acc = accuracy_score(y_train_gpu, y_pred_train)
        test_acc = accuracy_score(y_test_gpu, y_pred_test)
        
        elapsed = time.time() - start_time
        
        if test_acc > best_acc:
            best_acc = test_acc
            best_model = svm
            best_marker = " [BEST]"
        else:
            best_marker = ""
        
        print(f"Epoch {epoch+1:2d}/{epochs}: C={C_current:8.4f} | "
              f"Train Acc: {train_acc*100:5.2f}% | Test Acc: {test_acc*100:5.2f}% | "
              f"Time: {elapsed:.2f}s{best_marker}")
    
    print("=" * 60)
    print(f"Best Test Accuracy: {best_acc*100:.2f}%")
    
    return best_acc, best_model


def train_svm_cpu(X_train, y_train, X_test, y_test, epochs=20, C=1.0):
    """Train SVM using sklearn (CPU)."""
    from sklearn.svm import SVC
    from sklearn.metrics import accuracy_score
    
    print("\nUsing sklearn (CPU) for SVM training")
    print("Note: CPU training is slower. Consider installing cuML for GPU acceleration.")
    
    # For CPU, we'll use a subset for faster training in early epochs
    print(f"\nTraining SVM with varying C values")
    print("=" * 60)
    
    best_acc = 0.0
    best_model = None
    C_values = np.logspace(-2, 2, epochs)  # C from 0.01 to 100
    
    for epoch in range(epochs):
        C_current = C_values[epoch]
        
        # Use subset for early epochs (faster)
        if epoch < 5:
            subset_size = min(5000, len(X_train))
            indices = np.random.choice(len(X_train), subset_size, replace=False)
            X_sub = X_train[indices]
            y_sub = y_train[indices]
        else:
            X_sub = X_train
            y_sub = y_train
        
        start_time = time.time()
        
        # Train SVM
        svm = SVC(C=C_current, kernel='rbf', gamma='scale', cache_size=2000)
        svm.fit(X_sub, y_sub)
        
        # Predict
        y_pred_train = svm.predict(X_sub)
        y_pred_test = svm.predict(X_test)
        
        # Accuracy
        train_acc = accuracy_score(y_sub, y_pred_train)
        test_acc = accuracy_score(y_test, y_pred_test)
        
        elapsed = time.time() - start_time
        
        if test_acc > best_acc:
            best_acc = test_acc
            best_model = svm
            best_marker = " [BEST]"
        else:
            best_marker = ""
        
        samples_used = len(X_sub)
        print(f"Epoch {epoch+1:2d}/{epochs}: C={C_current:8.4f} | "
              f"Train Acc: {train_acc*100:5.2f}% ({samples_used} samples) | "
              f"Test Acc: {test_acc*100:5.2f}% | Time: {elapsed:.2f}s{best_marker}")
    
    print("=" * 60)
    print(f"Best Test Accuracy: {best_acc*100:.2f}%")
    
    return best_acc, best_model


def train_linear_svm_gpu(X_train, y_train, X_test, y_test, epochs=20):
    """Train Linear SVM - faster than RBF."""
    try:
        import cupy as cp
        from cuml.svm import LinearSVC
        from cuml.metrics import accuracy_score
        print("\nUsing cuML LinearSVC (GPU)")
        use_gpu = True
    except ImportError:
        print("cuML not available, falling back to sklearn")
        from sklearn.svm import LinearSVC
        from sklearn.metrics import accuracy_score
        use_gpu = False
        
        print("\nUsing sklearn LinearSVC (CPU)")
        print("=" * 60)
        
        best_acc = 0.0
        best_model = None
        C_values = np.logspace(-3, 1, epochs)
        
        for epoch in range(epochs):
            C_current = C_values[epoch]
            start_time = time.time()
            
            svm = LinearSVC(C=C_current, max_iter=1000, dual=False)
            svm.fit(X_train, y_train)
            
            train_acc = svm.score(X_train, y_train)
            test_acc = svm.score(X_test, y_test)
            
            elapsed = time.time() - start_time
            
            if test_acc > best_acc:
                best_acc = test_acc
                best_model = svm
                best_marker = " [BEST]"
            else:
                best_marker = ""
            
            print(f"Epoch {epoch+1:2d}/{epochs}: C={C_current:8.5f} | "
                  f"Train Acc: {train_acc*100:5.2f}% | Test Acc: {test_acc*100:5.2f}% | "
                  f"Time: {elapsed:.2f}s{best_marker}")
        
        print("=" * 60)
        print(f"Best Test Accuracy: {best_acc*100:.2f}%")
        return best_acc, best_model
    
    # GPU path
    X_train_gpu = cp.asarray(X_train, dtype=cp.float32)
    y_train_gpu = cp.asarray(y_train, dtype=cp.int32)
    X_test_gpu = cp.asarray(X_test, dtype=cp.float32)
    y_test_gpu = cp.asarray(y_test, dtype=cp.int32)
    
    print("=" * 60)
    
    best_acc = 0.0
    best_model = None
    C_values = np.logspace(-3, 1, epochs)
    
    for epoch in range(epochs):
        C_current = C_values[epoch]
        start_time = time.time()
        
        svm = LinearSVC(C=C_current, max_iter=1000)
        svm.fit(X_train_gpu, y_train_gpu)
        
        y_pred_train = svm.predict(X_train_gpu)
        y_pred_test = svm.predict(X_test_gpu)
        
        train_acc = accuracy_score(y_train_gpu, y_pred_train)
        test_acc = accuracy_score(y_test_gpu, y_pred_test)
        
        elapsed = time.time() - start_time
        
        if test_acc > best_acc:
            best_acc = test_acc
            best_model = svm
            best_marker = " [BEST]"
        else:
            best_marker = ""
        
        print(f"Epoch {epoch+1:2d}/{epochs}: C={C_current:8.5f} | "
              f"Train Acc: {train_acc*100:5.2f}% | Test Acc: {test_acc*100:5.2f}% | "
              f"Time: {elapsed:.2f}s{best_marker}")
    
    print("=" * 60)
    print(f"Best Test Accuracy: {best_acc*100:.2f}%")
    
    return best_acc, best_model


def main():
    import argparse
    import pickle
    
    parser = argparse.ArgumentParser(description='Train SVM on autoencoder features')
    parser.add_argument('--features', type=str, default='cifar10_features',
                        help='Prefix for feature files')
    parser.add_argument('--epochs', type=int, default=20,
                        help='Number of training epochs (C value iterations)')
    parser.add_argument('--kernel', type=str, default='linear', choices=['linear', 'rbf'],
                        help='SVM kernel type')
    parser.add_argument('--C', type=float, default=1.0,
                        help='SVM regularization parameter (only used as base for rbf)')
    parser.add_argument('--save_model', type=str, default='',
                        help='Path to save best SVM model (pickle format)')
    args = parser.parse_args()
    
    print("=" * 60)
    print("         SVM Training on Autoencoder Features")
    print("=" * 60)
    
    # Load features
    X_train, y_train, X_test, y_test = load_features(args.features)
    
    # Normalize
    print("\nNormalizing features...")
    X_train, X_test = normalize_features(X_train, X_test)
    print(f"  Train mean: {X_train.mean():.6f}, std: {X_train.std():.6f}")
    print(f"  Test mean:  {X_test.mean():.6f}, std: {X_test.std():.6f}")
    
    # Train SVM
    if args.kernel == 'linear':
        best_acc, best_model = train_linear_svm_gpu(X_train, y_train, X_test, y_test, args.epochs)
    else:
        best_acc, best_model = train_svm_gpu(X_train, y_train, X_test, y_test, args.epochs, args.C)
    
    # Save model if requested
    if args.save_model and best_model is not None:
        print(f"\nSaving best model to '{args.save_model}'...")
        with open(args.save_model, 'wb') as f:
            pickle.dump(best_model, f)
        print("Model saved.")
    
    print(f"\n{'='*60}")
    print(f"Final Best Test Accuracy: {best_acc*100:.2f}%")
    print(f"{'='*60}")


if __name__ == '__main__':
    main()
